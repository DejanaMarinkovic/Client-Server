from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

names_dict = {
    'john': 'smith',
    'david': 'jones',
    'michael': 'johnson',
    'chris': 'lee'
}

class RequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.log_message("Incoming GET request...")
        parsed_url = urlparse(self.path)
        query_params = parse_qs(parsed_url.query)
        if 'name' not in query_params:
            self.send_response_to_client(400, 'Name parameter missing')
            self.log_message("Name parameter missing")
            return

        name = query_params['name'][0]
        if name in names_dict:
            self.send_response_to_client(200, names_dict[name])
        else:
            self.send_response_to_client(404, 'Name not found')
            self.log_message("Name not found")

    def do_POST(self):
        self.log_message('Incoming POST request...')
        data = parse_qs(self.path[2:])
        if 'name' not in data or 'last_name' not in data:
            self.send_response_to_client(400, 'Incorrect parameters provided')
            self.log_message("Incorrect parameters provided")
            return

        name = data['name'][0]
        last_name = data['last_name'][0]
        names_dict[name] = last_name
        self.send_response_to_client(200, str(names_dict))

    def do_DELETE(self):
        self.log_message('Incoming DELETE request...')
        parsed_url = urlparse(self.path)
        query_params = parse_qs(parsed_url.query)
        if 'name' not in query_params:
            self.send_response_to_client(400, 'Name parameter missing')
            self.log_message("Name parameter missing")
            return

        name = query_params['name'][0]
        if name in names_dict:
            del names_dict[name]
            self.send_response_to_client(200, 'Name deleted')
        else:
            self.send_response_to_client(404, 'Name not found')
            self.log_message("Name not found")

    def send_response_to_client(self, status_code, data):
        # Send OK status
        self.send_response(status_code)
        # Send headers
        self.send_header('Content-type', 'text/plain')
        self.end_headers()
        # Send the response
        self.wfile.write(data.encode())

server_address = ('127.0.0.1', 8080)
http_server = HTTPServer(server_address, RequestHandler)
http_server.serve_forever()
